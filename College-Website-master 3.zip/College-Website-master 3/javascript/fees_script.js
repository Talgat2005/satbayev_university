function getInputValue(){

    let inputVal=document.getElementById("uid").value;
    let a=1;

    if(inputVal==1){
        document.getElementById("demo").innerHTML ="AMANULLAH RAHAMATULLABHAI ATHANIYA";
        document.getElementById("demo1").innerHTML ="10000";
    }
    else if(inputVal==2)
    {
        document.getElementById("demo").innerHTML ="No Records Found";
        document.getElementById("demo1").innerHTML ="0";  
    }
    else if(inputVal==3)
    {
        document.getElementById("demo").innerHTML ="TRUPTKUMAR GIRISHBHAI BARIA";
        document.getElementById("demo1").innerHTML ="10000";   
    }

    else if(inputVal==4)
    {
        document.getElementById("demo").innerHTML ="JAY VIJAYKUMAR BHANUSHALI";
        document.getElementById("demo1").innerHTML ="10000";   
    }
    else if(inputVal==5)
    {
        document.getElementById("demo").innerHTML ="SMITKUMAR DINESHKUMAR BHEDA";
        document.getElementById("demo1").innerHTML ="10000";   
    }
    else if(inputVal==6)
    {
        document.getElementById("demo").innerHTML ="VIKAS SHANTIBHAI CHAUDHARY";
        document.getElementById("demo1").innerHTML ="20000";   
    }
    else if(inputVal==7)
    {
        document.getElementById("demo").innerHTML ="NIRAVKUMAR AMIRAMBHAI CHAUHAN";
        document.getElementById("demo1").innerHTML ="20000";   
    }
    else if(inputVal==8)
    {
        document.getElementById("demo").innerHTML ="MOHAMMAD HARUN CHOUDHARY";
        document.getElementById("demo1").innerHTML ="0";   
    }
    else if(inputVal==9)
    {
        document.getElementById("demo").innerHTML ="ZAIDALI MEHDIHUSSAIN CHOUDHARY";
        document.getElementById("demo1").innerHTML ="10000";   
    }
    else if(inputVal==10)
    {
        document.getElementById("demo").innerHTML ="AMIT DAHYABHAI DASADIYA";
        document.getElementById("demo1").innerHTML ="7500";   
    }

     else if(inputVal==11)
    {
        document.getElementById("demo").innerHTML ="JAYDIP VASANTKUMAR GOMTIVAL";
        document.getElementById("demo1").innerHTML ="0";   
    }
     else if(inputVal==12)
    {
        document.getElementById("demo").innerHTML ="GULSHAN MOHANKUMAR GUPTA";
        document.getElementById("demo1").innerHTML ="20000";   
    }
    else if(inputVal==13)
    {
        document.getElementById("demo").innerHTML ="TAUHID MAHAMMADTALHA JUNAKIYA";
        document.getElementById("demo1").innerHTML ="7500";   
    }  
    else if(inputVal==14)
    {
        document.getElementById("demo").innerHTML ="MAHMILFATEMA PARVEZALI KADIWALA";
        document.getElementById("demo1").innerHTML ="10000";   
    }
    else if(inputVal==15)
    {
        document.getElementById("demo").innerHTML ="ADANAN ABDULAJIJ MAKNOJIYA";
        document.getElementById("demo1").innerHTML ="2500";   
    }
    else if(inputVal==16)
    {
        document.getElementById("demo").innerHTML ="MOHAMMADADIL MAHEBUBKHAN MOGAL";
        document.getElementById("demo1").innerHTML ="10000";   
    }
    else if(inputVal==17)
    {
        document.getElementById("demo").innerHTML ="MANSIBEN HARESHBHAI NAYI";
        document.getElementById("demo1").innerHTML ="10000";   
    }

    else if(inputVal==18)
    {
        document.getElementById("demo").innerHTML ="AZRUDDIN ASLAMBHAI PALASARA";
        document.getElementById("demo1").innerHTML ="20000"; 
    }
    else if(inputVal==19)
    {
        document.getElementById("demo").innerHTML ="ALPESHKUMAR BALUBHAI PARMAR";
        document.getElementById("demo1").innerHTML ="0"; 
    }
    else if(inputVal==20)
    {
        document.getElementById("demo").innerHTML ="ROHITKUMAR JASVANTBHAI PARMAR";
        document.getElementById("demo1").innerHTML ="2500"; 
    }
     else if(inputVal==21)
    {
        document.getElementById("demo").innerHTML ="RAVIKUMAR ASHOKBHAI PATEL";
        document.getElementById("demo1").innerHTML ="1000"; 
    }
    else if(inputVal==22)
    {
        document.getElementById("demo").innerHTML ="SAHILKUMAR ARVINDBHAI PATEL";
        document.getElementById("demo1").innerHTML ="20000"; 
    }
    else if(inputVal==23)
    {
        document.getElementById("demo").innerHTML ="SAKSHI KIRTIKUMAR PATEL";
        document.getElementById("demo1").innerHTML ="10000"; 
    }
    else if(inputVal==24)
    {
        document.getElementById("demo").innerHTML ="DIGESH KIRTIBHAI PRAJAPATI";
        document.getElementById("demo1").innerHTML ="0"; 
    }
    else if(inputVal==25)
    {
        document.getElementById("demo").innerHTML ="SHAILESHKUMAR NARESHBHAI PRAJAPATI";
        document.getElementById("demo1").innerHTML ="7500"; 
    }
    else if(inputVal==26)
    {
        document.getElementById("demo").innerHTML ="VIKASHBHAI NARESHBHAI PRAJAPATI";
        document.getElementById("demo1").innerHTML ="10000"; 
    }
     else if(inputVal==27)
    {
        document.getElementById("demo").innerHTML ="KRUPAL SHAILESHKUMAR RAJPUT";
        document.getElementById("demo1").innerHTML ="10000"; 
    }
    else if(inputVal==28)
    {
        document.getElementById("demo").innerHTML ="MAHAMAD HANIF FARUKBHAI SAIYED";
        document.getElementById("demo1").innerHTML ="10000"; 
    }

    else if(inputVal==29)
    {
        document.getElementById("demo").innerHTML ="DIVY CHANDRAKANT SHUKLA";
        document.getElementById("demo1").innerHTML ="0"; 
    }
     else if(inputVal==30)
    {
        document.getElementById("demo").innerHTML ="JAYDIPSINH JASHVANTSINH SOLANKI";
        document.getElementById("demo1").innerHTML ="0"; 
    }
    else if(inputVal==31)
    {
        document.getElementById("demo").innerHTML ="MOHAMMADMISAM ALIAKBAR SUNASARA";
        document.getElementById("demo1").innerHTML ="2500"; 
    }
    else if(inputVal==32)
    {
        document.getElementById("demo").innerHTML ="MUSKANFATEMA NASIMHAIDAR SUNASARA";
        document.getElementById("demo1").innerHTML ="10000"; 
    }
    else if(inputVal==33)
    {
        document.getElementById("demo").innerHTML ="SAHILBHARATHI HIRABHARATHI SWAMI";
        document.getElementById("demo1").innerHTML ="7500"; 
    }
    else if(inputVal==34)
    {
        document.getElementById("demo").innerHTML ="NONSINGJI VANARAJJI THAKOR";
        document.getElementById("demo1").innerHTML ="20000 + 2500 = 22500"; 
    }
    else if(inputVal==35)
    {
        document.getElementById("demo").innerHTML ="ADITYA SURESHBHAI TONGDA";
        document.getElementById("demo1").innerHTML ="10000"; 
    }
    else{
        document.getElementById("demo").innerHTML ="No Records Found";
        document.getElementById("demo1").innerHTML ="0";
    }
    
}

